/*
 * main.cpp
 *
 *  Created on: 01-Mar-2026
 *      Author: Shilbhushan
 */


#include <iostream>

using namespace std;

class Student{
	int rollNo;
	float marks;

public:

	Student(){
		cout << "Default Constructor..." << endl;
	}


	float getMarks() const {
		return marks;
	}

	void setMarks(float marks) {
		this->marks = marks;
	}

	int getRollNo() const {
		return rollNo;
	}

	void setRollNo(int rollNo) {
		this->rollNo = rollNo;
	}

	~Student(){
			cout << "Desctructor..." << endl;
	}
};


int main(){

	Student s1;		// s1 object created on stack

	Student* s2 = new Student();		// s2 object created on heap

	Student* s3 = (Student*)malloc(sizeof(Student));	// create memory on heap without calling constructor

	cout <<  "in main.."<< endl;

	free(s3);	// free the memory by malloc
	delete s2;	// calls destructor to free the memory
}

