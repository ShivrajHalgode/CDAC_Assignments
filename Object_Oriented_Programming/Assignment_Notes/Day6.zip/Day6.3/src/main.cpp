/*
 * main.cpp
 *
 *  Created on: 01-Mar-2026
 *      Author: Shilbhushan
 */

#include <iostream>
using namespace std;

int main(){

//	int arr[3];	// creation of array on stack

	int* arr = new int[3]; // creation of array on heap

	int rows, cols;

	int** mat = new int*[rows];

	cout << *(arr) - *(arr) << endl;		// pointer arithmetic
	cout << arr+1 << endl;
	cout << arr+2 << endl;
	cout << arr+3 << endl;

	// &arr + 1

//	delete arr;	//memory leakage

	delete[] arr;	//new[] = delete[]

	return 0;
}





