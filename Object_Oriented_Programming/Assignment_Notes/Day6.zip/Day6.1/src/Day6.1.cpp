//============================================================================
// Name        : 1.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

using namespace std;

class Student{
	int rollNo;
	float marks;
	mutable int viewCount;

public:
	enum class Grade{A=10, B, C=30, D};

	enum class Division{
		A, B, C, D
	};

//	enum ERROR_CODE{
//		NOT_FOUND = 404,
//		UNAUTHORISED = 403,
//		INTERNAL_SERVER_ERROR = 501,
//		NULL_PTR = 500
//	};


	Student(){
		cout << "Default cons" << endl;
		rollNo = 0;
		marks = 0;
	}

	Student(int rollNo, float marks, int viewCount) : rollNo(rollNo), marks(marks), viewCount(viewCount){

	}

	float getMarks() const {
		return marks;
	}

	Student& setMarks(float marks) {
		this->marks = marks;
		return *this;
	}

	int getRollNo() const {
		return rollNo;
	}

	Student& setRollNo(int rollNo) {
		this->rollNo = rollNo;
		return *this;
	}

	void viewStudentData() const {
		viewCount++;
		cout << this->rollNo << " | " << this->marks << endl;
	}

	~Student(){
		cout << "Destructor" << endl;
	}
};	//student class ends here

inline void func(){
	cout << "hello" << endl;
}

int main(){

	Student s(101,50,0);	// object create -> constructor will be called

//	Student s[3];	// array of objects


	s.viewStudentData();

	s.getRollNo();	// return rollNo;

//	s.Division::A;

	cout << static_cast<int>(s.Division::A)<<endl;

	// for older enum
//	cout << s.A << endl;
//	cout << s.B << endl;
//	cout << s.C << endl;
//	cout << s.D << endl;

	return 0;
}


int main1() {
	Student s;

	s.setRollNo(101).setMarks(40);

	cout <<s.getRollNo() << " | " << s.getMarks() << endl;
	return 0;
}
