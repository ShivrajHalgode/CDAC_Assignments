//============================================================================
// Name        : 4.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Student {
	int* rollNo;
public:

	Student(){
		cout << "Defualt constructor..."<<endl;
		rollNo = nullptr;
	}

	Student(int* rollNo){
		cout << "Para constructor..."<<endl;
		this->rollNo = rollNo;
	}

	Student(const Student& s){
//		this->rollNo = s.rollNo;		// shallow copy
		cout << "DC constructor..."<<endl;
		this->rollNo = new int(*s.rollNo); 	// deep copy
	}

	int* getRollNo() const {
		return rollNo;
	}

	void setRollNo(int* rollNo) {
		this->rollNo = rollNo;
	}

	~Student(){
		cout << "Destructor called..." << this << " rollNo address: " << this->rollNo <<endl;
		delete rollNo;
	}

};


int main() {

//	int num = 10;
//
//	int* ptrNum = &num;		// ptr variable pointing to num address
//
//	int& ref = num;			// alias for num only


	int* p = new int(122);

	Student s1(p);		// object created on stack

	Student s2 = s1;		// this is calling CC default copy constructor


//	Student s2 = s1;		// object initialization

	Student s3;		// object creation

	s3 = s1;		// object assignment

	cout << " s1 : " << &s1 << endl;
	cout << " s2 : "<< &s2 << endl;
	cout << " s3 : "<< &s3 << endl;
	cout << s1.getRollNo() << endl;
	cout << s2.getRollNo() << endl;
	cout << s3.getRollNo() << endl;


	return 0;
}
