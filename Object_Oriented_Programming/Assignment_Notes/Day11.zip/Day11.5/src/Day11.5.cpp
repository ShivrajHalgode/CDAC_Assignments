//============================================================================
// Name        : 5.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <stack>
#include <queue>
using namespace std;

class Student{
public:
	int rollNo;
	double marks;

	Student(): rollNo(0), marks(0){

	}

	Student(int rollNo, double marks): rollNo(rollNo), marks(marks){

	}

	void display(){
		cout << rollNo << " | " << marks << endl;
	}
};

int main() {

	stack<Student> s;

	s.emplace(101, 30);			// data at back
	s.push(Student(102,65));

	s.pop();			// data/object from top deleted
	s.empty();

	s.size();

	s.top().display();


	queue<Student> q;

	q.emplace(101,50);	// add data at back
	q.push(Student(102,57));		// add data at back
	q.back();
	q.front();

	q.pop();		// delete data from front

	q.size();
	q.empty();

	return 0;
}
