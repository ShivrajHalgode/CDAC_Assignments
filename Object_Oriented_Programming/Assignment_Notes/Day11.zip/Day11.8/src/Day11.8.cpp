//============================================================================
// Name        : 8.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <typeinfo>

using namespace std;

class Base{

	virtual void show(){
		cout << "base" <<endl;
	}
};

class Derived : public Base{
	void show(){
		cout << "derived" <<endl;
	}
};

//RTTI : Run Time Type Information

//const_cast : const variable/function using const_cast we can change the const to non-const,
//																		 non-const to const

void show(int* p){
	 cout <<"show: " << *p << endl;
}


extern int shil;	// suggest you variable is defined somewhere else in another file


int main(){

	int x = 65;

	char c = x;		//ASCII value of 65 will be treated as A

	int* ptr = &x;

	long address = reinterpret_cast<long>(ptr);

	cout << c <<endl;
	cout << address <<endl;

	return 0;
}

int main2(){

	const int x = 10;

	int* ptr = const_cast<int*>(&x);

	*ptr = 20; 	//const: through ptr


	const int y = 20;
//	int* p = &y;

	show(const_cast<int*>(&y));


//	const to non-const

//	non-const to const
//	const_cast<const int*>(val);


	cout << *ptr << endl;

	return 0;
}


int main1() {

	int x = 10;
//	double y = 10.5;

	//compile time check -> base object

	double y = static_cast<int>(x);	//upcasting

	Base *b = new Derived();

	Derived *d;

//	b = d;		//upcasting

	d = dynamic_cast<Derived*>(b);

//	static_cast		= compile casts the elements or object in compile time

//	compile casting we use static_cast


	int a = static_cast<int>(y);		//downcasting

//	Derived d;

	cout << typeid(x).name() << endl;
	cout << typeid(y).name() << endl;
	cout << typeid(a).name() << endl;

	cout << typeid(b).name() << endl;
	cout << typeid(d).name() << endl;

//	int show(Derived d){
//
//	}
//
//	show(dynamic_cast<Derived>(d));

	return 0;
}
