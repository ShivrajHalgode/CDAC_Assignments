/*
 * externDemo.cpp
 *
 *  Created on: 07-Mar-2026
 *      Author: Shilbhushan
 */

int shil = 10;



