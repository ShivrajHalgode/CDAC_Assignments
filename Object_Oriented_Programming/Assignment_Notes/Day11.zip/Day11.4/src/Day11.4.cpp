//============================================================================
// Name        : 4.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <list>
using namespace std;

class Student{
public:
	int rollNo;
	double marks;

	Student(): rollNo(0), marks(0){

	}

	Student(int rollNo, double marks): rollNo(rollNo), marks(marks){

	}

	void display(){
		cout << rollNo << " | " << marks << endl;
	}
};


int main(){


	//doubly linkedlist structur
//	| prev.ptr | data | next.ptr|

	list<Student> l;

	l.emplace_back(101,40);
	l.emplace_front(102,57);
	l.push_back(Student(104,89));
	l.push_front(Student(105,67));

//	l.front();
//	l.back();
//	l.end();
//	l.size();
//	l.clear();
////	l.erase();
//	l.empty();
//	l.insert(l.begin() + 2, l.begin(), l.end());
//	l.pop_back();
//	l.pop_front();


	list<Student>::iterator it;

	for(it = l.begin();it != l.end();it++){
		it->display();
	}

	// to add element at a position
	it = l.begin();

	advance(it, 2);

	l.insert(it, Student(103,30));

	cout << "==================" << endl;

	for(auto s1:l)
		s1.display();


	return 0;
}
