//============================================================================
// Name        : 6.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <map>
using namespace std;

class Student{
public:
	int rollNo;
	double marks;

	Student(): rollNo(0), marks(0){

	}

	Student(int rollNo, double marks): rollNo(rollNo), marks(marks){

	}

	void display(){
		cout << rollNo << " | " << marks << endl;
	}
};


int main() {

//	map key - value pair
	map<int, Student> m;

//	m.emplace(10, "shil")
	m.emplace(2, Student(101, 45));
	m.emplace(1, Student(106, 65));
	m.emplace(5, Student(102, 75));
	m.emplace(4, Student(103, 85));
	m.insert({7, Student(102, 45)});

//	map<int, int> ;		key = int value = int : 20

//	m.begin();
//	m.end();
//	m.clear();
//	m.count(Student(101,38));
//	m.empty();
//	m.find(Student(102,38));
//	m.at(101);		// values

	for(auto m1 : m){
//		m1.first  key ka value
		 m1.second.display();   // value ka value access
	}

	return 0;
}
