//============================================================================
// Name        : 7.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {

	vector<int> v{10,20,45,67,13};

	vector<int>::iterator it;

//	++, --, * : can be used

	for(it = v.begin();it != v.end(); it++){
		cout << *it << endl;
	}

	cout << "====================" << endl;
	// to traverse in reverse order
//	vector<int>::reverse_iterator rit;
	for(auto it = v.rbegin();it != v.rend(); it++){
		cout << *it << endl;
	}

	sort(v.begin(), v.end(), greater<int>());

	cout << "====================" << endl;

	for(it = v.begin();it != v.end(); it++){
		cout << *it << endl;
	}

	reverse(v.begin(), v.end());


	cout << "====================" << endl;

	for(it = v.begin();it != v.end(); it++){
		cout << *it << endl;
	}

	find(v.begin(), v.end(), 20);

	max_element(v.begin(), v.end());

	min_element(v.begin(), v.end());

//	find_if(v.begin(), v.end(), [](int a, int b){
//		return a == b;
//	});
//
//	remove_if(v.begin(), v.end(), [r](Student s){
//		return s.rollNo == r;
//	})

	return 0;
}
