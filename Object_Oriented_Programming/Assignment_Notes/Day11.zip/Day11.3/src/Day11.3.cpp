//============================================================================
// Name        : 3.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>
using namespace std;

// STL : Standard Template Library
//- Containers
//- Iterators
//- Algorithms

// Templates + Data structures + Algorithms
//- vector
//- list
//- stack
//- queue
//- map

class Student{
public:
	int rollNo;
	double marks;

	Student(): rollNo(0), marks(0){

	}

	Student(int rollNo, double marks): rollNo(rollNo), marks(marks){

	}

	void display(){
		cout << rollNo << " | " << marks << endl;
	}
};


int main(){

	vector<Student> s;

	s.push_back(Student(101,56));
	s.push_back(Student(102,78));	//
	s.emplace_back(103,89);			// better for object/prim data_types

//	push_back: temp object create -> copy it inside vector
//	emplace_back: copy directly inside the vector -> class constructor

	vector<Student>::iterator it;

	for(it = s.begin();it != s.end();it++){
		it->display();
	}

	for(auto s1:s)
		s1.display();


	return 0;
}


int main1() {

	vector<int> v;

	v.push_back(10);
	v.push_back(20);
	v.push_back(30);

	cout << "=====================" << endl;
	cout << v[1] << endl;	// you can access it via array way also
	cout << v.at(1) << endl;	// you can access it via at method

	cout << "=====================" << endl;

	cout <<"Size: "<< v.size() << endl;
	cout <<"Capacity: " <<  v.capacity() << endl;

	v.push_back(40);

	cout << "=====================" << endl;
	cout <<"Size: "<< v.size() << endl;
	cout <<"Capacity: " <<  v.capacity() << endl;

	v.push_back(50);

	cout << "=====================" << endl;
	cout <<"Size: "<< v.size() << endl;
	cout <<"Capacity: " <<  v.capacity() << endl;


	//1. traversing and printing
	// Normal loop
	for(int i=0;i<v.size();i++){
		cout << v.at(i) << endl;
	}

	cout << "=====================" << endl;
	//2. traversing and printing
	// Range-Based loop
	for(auto i: v){
		cout << i << endl;
	}

	cout << "=====================" << endl;
	//3. Iterator
	vector<int>::iterator it;

	for(it = v.begin();it != v.end();it++){
		cout << *it << endl;
	}

//	v.pop_back();		// removes the last element
//	v.front();			// get the value of 1st element
//	v.end();				// get the value of last element
//	v.at(1);				// gives value at a index
//	v.clear();			// removes all elements
//	v.erase(v.begin()+1);			// erases positioned element
//	v.empty()			// if vector is empty

	return 0;
}
