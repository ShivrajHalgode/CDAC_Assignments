//============================================================================
// Name        : 1.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

// function overloading
//int add(int a, int b){
//	return a + b;
//}
//
//double add(double a, double b){
//	return a + b;
//}

//function template	for add function
template <typename T>	// T : it is alias: A,b shil, etc. but T is a standard
//template <class T>		// typename = class written in <typename> = <class>
T add(T a, T b){
	return a + b;
}

template <typename T, typename U>	// U: an alias or name, U: standard way
U add(T a, U b){
	return a + b;
}


int main() {

	cout << add(10.43,20.62) << endl;
	cout << add(10,20) << endl;
	cout << add(10, 40.5) << endl;
	cout << add(29.45, 20) << endl;


	return 0;
}
