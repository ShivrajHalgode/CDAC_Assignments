//============================================================================
// Name        : 2.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class A{
public:
	int x;
	A() : x(0){

	}

	A(int x) : x(x){
	}
};



int main1() {

	A a(0);
	A a1(10.6);
	A a2('A');

	cout << a.x << endl;
	cout << a1.x << endl;
	cout << a2.x << endl;

	return 0;
}

//LIFO: Data Structure -> acts as ds to store data in LIFO manner

// push, pop, peek, top

//class template
template <typename T>
class Stack{
	T arr[100];		// int arr[100];
	int top;
public:

	Stack(){
		top = -1;
	}

	void push(T val){		//push(int val)
		arr[++top] = val;
	}

	T pop(){				//int pop()
		return arr[top--];
	}

	T peek(){		//int peek()
		return arr[top];
	}
};

class Student{
public:
	int rollNo;
	double marks;

	Student(): rollNo(0), marks(0){

	}

	Student(int r, double m) : rollNo(r), marks(m){

	}

	void display(){
		cout << rollNo << " " << marks << endl;
	}

};

int main(){
	Stack<int> s;	//class datatype <int>

	Stack<Student> studentsStack;	// stack will be for student objects

	s.push(10);
	s.push(20);
	s.push(30);

	cout << s.peek() << endl;

	s.pop();

	cout << s.peek() << endl;

}

