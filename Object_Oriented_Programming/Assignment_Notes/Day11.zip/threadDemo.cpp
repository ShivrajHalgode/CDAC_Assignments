#include <iostream>
#include <thread>
#include <chrono>
using namespace std;

void printNumbers(){
	for(int i=0;i<5;i++)
		cout << i << " ";
        this_thread::sleep_for(chrono::milliseconds(200)); // Sleep for 200 milliseconds
}

void printEven(){
	for(int i=0;i<5;i++){
		if(i%2 == 0)
			cout << i << " ";
	}
}

int main(){

	thread t1(printEven);
    thread t2(printNumbers);

	t1.join();
	t2.join();

	return 0;
}