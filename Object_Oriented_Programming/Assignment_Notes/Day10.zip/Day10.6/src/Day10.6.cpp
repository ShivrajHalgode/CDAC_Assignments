//============================================================================
// Name        : 6.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
using namespace std;

int main(){

	ofstream ofs;
	ofs.open("data.txt", ios::app);	//append
//						ios::ate		//at the end
//						ios::trunc	//truncate the data and write new
//						ios::binary	//directly write the raw data as it is

	ofs << "Hi this is BDA Student!" << endl;

	ofs.close();		// this is recommended.

	ifstream ifs;

	ifs.open("data.txt", ios::app);

	string line;

	while(getline(ifs,line))
		cout << line << endl;

	ifs.close();		// this is recommended.

	return 0;
}





int main1() {

//	ifstream -> input stream		-> read data from a file
//	ofstream -> output stream	-> write data to a file

	ofstream ofs("data.txt");

	ofs << "Hi this is AC Student!" << endl;


	ifstream ifs("data.txt");

	string line;

//	ifs >> line;
	getline(ifs, line);

	cout << line << endl;



	cout << "Program end." << endl;

	return 0;
}
