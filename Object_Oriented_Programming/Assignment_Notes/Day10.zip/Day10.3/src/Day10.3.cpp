//============================================================================
// Name        : 3.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int divide(int a, int b){
	try{
		if(b == 0)
			throw "Divide by zero!";
	}catch(const char* e){
		cerr <<"Divide Catch: "<< e << endl;
	}
	return a/b;
}

int main2(){

	try{
//		throw "Some Exception in logic!";

		divide(10,0);

	} catch(const char* e){
		cerr <<"Main Catch: "<< e << endl;
	}
	return 0;
}

int main1() {
	try{
//		throw "outer throw";	// some business logic that can throw exception
		try{
			throw "inner throw!";
		}catch(const char* c){
			cerr << "Exception: "<< c << endl;
		}

	}catch(const char* c){
		cerr << "Exception: " << c << endl;
	}

	return 0;
}

int main() {
	try{
//		throw "outer throw";	// some business logic that can throw exception
		try{
			// some business logical work
			throw "inner throw!";
		}catch(const char* c){
			cout << "Inside inner catch!" << endl;
			throw;	//rethrow
			cerr << "Inner Catch: "<< c << endl;
		}

	}catch(const char* c){
		cerr << "Outer Catch: " << c << endl;
	}

	return 0;
}
