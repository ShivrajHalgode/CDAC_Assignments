/*
 * main.cpp
 *
 *  Created on: 06-Mar-2026
 *      Author: Shilbhushan
 */
#include <iostream>
#include <iomanip>
using namespace std;

int main(){
	int a = 10;

	double d = 10.4683;

	cout << setw(10) << a << endl;
	cout << setw(10) << fixed << setprecision(2) << d << endl;

	string name;
	char c;

	cout << "Enter the name: " << endl;
//	cin >> name;
	getline(cin, name);

	cout << "Enter char:" << endl;
	cin.get(c);

	cout << "Name: " << name << endl;
	cout << "Char: " << c << endl;


	cerr << "To Show Errors Quickly on console..." << endl;
	clog << "For logging on console..." << endl;

}
