//============================================================================
// Name        : 7.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
using namespace std;

// custom logger class for logging of students
class Logger{
	string line;
	ofstream ofs;

public:
	Logger(): line(""){
		ofs.open("Logs.txt", ios::app);
	}

	Logger(string line) : line(line){
		ofs.open("Logs.txt", ios::app);
	}

	void log(string line){
		ofs << line << endl;
	}

	~Logger(){
		ofs.close();
	}

};

class Student{
public:
	int rollNo;
	double marks;

	Logger logger;

	Student(int rollNo, double marks): rollNo(rollNo), marks(marks){
		logger.log("Student Created!" + to_string(rollNo)+ " " + to_string(marks));
	}

	~Student(){
		logger.log("Student Destroyed!");
	}
};


int main() {

	Student s1(101, 30);
	Student s2(103, 40);
	Student s3(105, 60);

	return 0;
}
