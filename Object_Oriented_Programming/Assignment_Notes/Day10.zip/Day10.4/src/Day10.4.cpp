//============================================================================
// Name        : 4.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class ArithmeticException : public exception{
	int line;
	string functionName;
	string fileName;
	string message;

public:
	ArithmeticException(int line, string functionName, string fileName) :
		line(line), functionName(functionName), fileName(fileName){
		message = "Arithmetic Exception: in"
				+ fileName + " : at "
				+ functionName + " : on line: "
				+ to_string(line);
	}

	const char* what() const noexcept override{
		return message.c_str();
	}
};

//__LINE__ : it is MACRO - represents current line
//__func__ : it is MACRO - it gives func name;
//__FILE__ : it is MACRO - it gives fileName;

#define ARITHMETICEXC ArithmeticException(__LINE__, __func__, __FILE__);

int divide(int a, int b){
	if(b == 0)
		throw ARITHMETICEXC;
	return a/b;
}

int main() {

	try{
		cout << divide(10,0) << endl;
	}
	catch(const exception& e){
		cerr << e.what() << endl;
	}

	return 0;
}
