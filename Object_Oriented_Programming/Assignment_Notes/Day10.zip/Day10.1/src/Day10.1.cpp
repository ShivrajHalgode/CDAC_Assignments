#include <iostream>
using namespace std;


int divide(int a , int b){
	if(b == 0)
		throw "Divide By Zero!";
	return a/b;
}

int main(){

	divide(10,0);
	try{
		int res = divide(10,0);

		cout << res << endl;

	}catch(const char* e){
		cerr << "Exeception: " << e << endl;
	}

	cout << "After Exception" << endl;

	return 0;
}




int main1() {

//	throw : int, char*, double, Object

	int arr[3];

	try{
		for(int i=0;i<3;i++){
			arr[i] = i;		// setting values in arr
		}
		for(int i=0;i<3;i++){
			if(i > 2)
				throw "Array out of Bounds!";
			cout << arr[i] << endl;
		}
	}
	catch(const char* msg){
		cerr << "Array ke bahar chale gaye..." << msg << endl;
	}

	return 0;
}
