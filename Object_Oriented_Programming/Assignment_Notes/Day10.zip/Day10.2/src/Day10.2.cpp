//============================================================================
// Name        : 2.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {


//	throw Object;
	try{

//	throw 10;		// throwing int

//	throw 10.67; 	// throwing double

	throw "message";	// throwing char*

	throw out_of_range("msg");

	}
	catch(const int i){
		cerr <<"Exception: "<< i << endl;
	}
	catch(const double d){
		cerr <<"Exception: "<< d << endl;
	}
	catch(const char* c){
		cerr <<"Exception: "<< c << endl;
	}
	// it is capable of catching all type of exceptions
	catch(...){
		cerr <<"Undefined Behaviour"<< endl;
	}

	cout << "After exception..." << endl;
	return 0;
}
