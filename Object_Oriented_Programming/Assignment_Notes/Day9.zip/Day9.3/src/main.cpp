/*
 * main.cpp
 *
 *  Created on: 05-Mar-2026
 *      Author: Shilbhushan
 */

#include <iostream>

using namespace std;

class Person{
public:
	string name;
	int age;
	Person() : name(""), age(0){
		cout << "Person Constructor Called!" << endl;
	}

	Person(string name, int age) : name(name), age(age) {
		cout << "Person Constructor Called!" << endl;
	}

	//early bindin without virtual
//	void showDetails(){
//		cout << name << " | " << age <<endl;
//	}

	//late binding with virtual
	virtual void showDetails(){
		cout << name << " | " << age <<endl;
	}

	virtual ~Person(){
		cout << "Person Destructor Called!" << endl;
	}
};

class Student : public Person{
public:
	int rollNo;
	Student() : rollNo(0){
		cout << "Student Constructor Called!" << endl;
	}

	Student(int rollNo) : rollNo(rollNo){
		cout << "Student Constructor Called!" << endl;
	}

	Student(int rollNo, string name, int age) : Person(name, age), rollNo(rollNo){
	}

	// function override
	void showDetails(){
		cout << rollNo << " | " << name << " | " << age << endl;
	}

	~Student(){
		cout << "Student Destructor Called!" << endl;
	}
};

class Employee : public Person{
public:
	int empId;
	Employee() : empId(0){
		cout << "Employee Constructor Called!" << endl;
	}

	Employee(int empId) : empId(empId){
		cout << "Employee Constructor Called!" << endl;
	}

	Employee(int empId, string name, int age) : Person(name, age), empId(empId){
	}

	// function override
	void showDetails(){
		cout << empId << " | " << name << " | " << age << endl;
	}

	~Employee(){
		cout << "Employee Destructor Called!" << endl;
	}
};

int main(){

	Student s1;

	return 0;
}



