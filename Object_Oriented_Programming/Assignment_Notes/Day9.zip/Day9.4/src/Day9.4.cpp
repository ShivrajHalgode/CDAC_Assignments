//============================================================================
// Name        : 4.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;


//function overloading : compile time polymorphism
//function signature = return_type functionName(parameters...)

// function overloading: return_type = x
//add(int, int);
//add(double,double);
//add(int, double);
//add(double int);
//add(int, int, int);
//int add();
//int add(int)

int add(int a, int b){
	return a + b;
}

double add(double a, double b){
	return a + b;
}

//add(10.5, 30.5);		//41 40 : double
//add(10, 20);				//integer

class A{
public:
	int x;

	void show(){
		cout << x << endl;
	}
};

class B : virtual public A{
public:
//	int y;

	// function overriding
//	void show() override{
//		cout << x << y<<  endl;
//	}
};

class C : virtual public A{

};


class D : public B, public C{

};


int main(){

	D d;

	C c;

	cout << sizeof(c) << endl;

//	cout << d.x << endl;
	cout << sizeof(d)<< endl;

	d.show();

	return 0;
}


int main1() {

	B b;

	b.show();

	return 0;
}
