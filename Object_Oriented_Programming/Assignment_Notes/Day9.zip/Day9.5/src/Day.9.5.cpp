//============================================================================
// Name        : 5.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;


// Interface
class IShape{
	virtual void draw() = 0;
};
// Interface style: it can have one or more pure virtual function



// Base class: Abstract Class
class Shape{
public:
	int sides;
	double area;
	double volume;

	virtual void draw() = 0;		//pure virtual function
	// when a class has pure virtual function it is called as abstract class
	// we cannot create object of abstract class
};


class Rectangle : public Shape{

public:
	void draw(){
		cout << "Drawing Rectangle..."<<endl;
	}
};

class Circle : public Shape{

};


int main() {

	Shape* s1 = new Rectangle();

	s1->draw();

	return 0;
}
