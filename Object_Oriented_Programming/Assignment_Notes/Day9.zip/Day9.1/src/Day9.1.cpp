//============================================================================
// Name        : 1.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Base{
public:
	int x;

	Base() : x(0){
		cout << "Base Default Constructor.."<< endl;
	}

	Base(int x): x(x){
		cout << "Base Para Constructor.."<< endl;
	}
};

class Derived : public Base{
public:
	int y;

	Derived(): y(0){
		cout << "Derived Default Constructor.."<< endl;
	}

	Derived(int y) : y(y){
		// Base();
		cout << "Derived Para Constructor.." << endl;
	}

	Derived(int x, int y): Base(x), y(y){
		cout << "Derived Para Constructor.." << endl;
	}
};


class Person{
public:
	string name;
	int age;
	Person() : name(""), age(0){
	}

	Person(string name, int age) : name(name), age(age) {
	}
};


class Student : public Person{
public:
	int rollNo;
	Student() : rollNo(0){
	}

	Student(int rollNo) : rollNo(rollNo){
	}

	Student(int rollNo, string name, int age) : Person(name, age), rollNo(rollNo){
	}
};

class Employee : public Person{
public:
	int empId;
	Employee() : empId(0){
	}

	Employee(int empId) : empId(empId){
	}

	Employee(int empId, string name, int age) : Person(name, age), empId(empId){
	}
};


int main(){

	Student s;	// default person -> default student;

	Student s1(101, "shil", 20);		// para person -> para student

	cout << s1.rollNo << " | " << s1.name << " | " << s1.age << endl;


	return 0;
}



int main1() {

	Derived d;	// derived class object

	Derived d1(10);		// para cons x = 0, y = 10;
	Derived d2(10,20);	// par cons

	cout << d1.x << endl;
	cout << d1.y << endl;

	cout << d2.x << endl;
	cout << d2.y << endl;

	return 0;
}
