//============================================================================
// Name        : 2.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Person{
public:
	string name;
	int age;
	Person() : name(""), age(0){
	}

	Person(string name, int age) : name(name), age(age) {
	}

	//early binding without virtual
//	void showDetails(){
//		cout << name << " | " << age <<endl;
//	}

	//late binding with virtual
	virtual void showDetails(){
		cout << name << " | " << age <<endl;
	}
};

class Student : public Person{
public:
	int rollNo;
	Student() : rollNo(0){
	}

	Student(int rollNo) : rollNo(rollNo){
	}

	Student(int rollNo, string name, int age) : Person(name, age), rollNo(rollNo){
	}

	// function override
	void showDetails(){
		cout << rollNo << " | " << name << " | " << age << endl;
	}
};

class Employee : public Person{
public:
	int empId;
	Employee() : empId(0){
	}

	Employee(int empId) : empId(empId){
	}

	Employee(int empId, string name, int age) : Person(name, age), empId(empId){
	}

	// function override
	void showDetails(){
		cout << empId << " | " << name << " | " << age << endl;
	}
};


int main(){
	Person p;

	Student s(101,"shil", 20);

	p = s;	// upcasting		object slicing

	p.showDetails();

	Person* p1 = new Person("shil", 20);	// person class object
	Person* p2 = new Student(101, "shil", 20);	// student class object

	Student* s1 = (Student*)p2; 	//(ClassName): older way

	Student* s2 = dynamic_cast<Student*>(p2);		//modern way to downcast


	s1->showDetails();

	int a = 10;

	double d = a;	// upcasting	: implicit


	double d1 = 10.82634;	// 10 = 10.0

	int a1 = d1;		// 10.71347 = 10		//slicing

	cout <<"Upcasting: from Int to Double: "<< d << endl;
	cout <<"Downcasting: from Double to Int: "<< a1 << endl;
}



int main1() {

	Person* ptrStd = new Student(101, "shil", 20);	// person -> student

	Person* ptrEmp = new Employee(11292, "Arun", 22);

	Student* s = new Student(102, "sanika", 22);

	ptrStd->showDetails();		// it is calling the base class func
	//Early Binding: binding the function call at compile time

	ptrEmp->showDetails();

	s->showDetails();

//	func(int)	// method overloading for int
//	func(double)// method overloading for double
//
//	func(10);	// at compile time decides which func to call
	return 0;
}
