//============================================================================
// Name        : 4.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;


// encapsulation
//class Student{
//	int data_member;
//public:
//	member_functions
//};

class Printer{
public:
	void printJob(){
		cout << "Printing..." << endl;
	}
};

class Computer{

public:
	void print(Printer* p){
		p->printJob();
	}
};


class Faculty{
	string name;
public:

	Faculty(string name): name(name){

	}

	void display(){
		cout << name << endl;
	}

};

class University{
 Faculty* faculty;

public:

 	 University(Faculty* faculty): faculty(faculty){

 	 }

 	 void facultyData(){
 		 faculty->display();
 	 }

};

class Heart{
public:
	void beats(){
		cout << "beating..." << endl;
	}
};

class Human{
public:
	Heart heart;		// composition -> object
};




int main() {
	Computer c;
	Printer p;

	c.print(&p);		// association

	Faculty f("shil");

	University u(&f);	// aggregation

	u.facultyData();

	Human h;

	h.heart.beats();		// composition

	return 0;
}
