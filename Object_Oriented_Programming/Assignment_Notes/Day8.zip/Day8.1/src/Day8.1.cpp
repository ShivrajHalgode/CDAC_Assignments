//============================================================================
// Name        : 1.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Complex{
	int real, imag;

public:

	//constructor overloading
	Complex() : real(0), imag(0){
	}

	Complex(int real, int imag) : real(real), imag(imag){
	}

	void display(){
		cout << real << " + " << imag << "i" << endl;
	}

	// member operator overloading
	Complex operator++(int){
		// temp object -> current obj state
		Complex temp = *this;	//10 + 20i

		real++;		//this->real;
		imag++;		// this->imag;

		return temp;		// return original state
	}

	// pre-increment
	Complex& operator++(){
		++real;
		++imag;
		return *this;
	}

	Complex(int real, int imag){
		this->real = real;
		this->imag = imag;
	}


	Complex operator=(int real, int imag){
		this->real = real;
		this->imag = imag;
	};

	friend ostream& operator<<(ostream& os, Complex& other);
	friend istream& operator>>(istream& is, Complex& other);
};

// non member operator overloading for << operator
ostream& operator<<(ostream& os, Complex& other){
	return os << other.real << " + " << other.imag << "i";
}

istream& operator>>(istream& is, Complex& other){
	return is >> other.real >> other.imag;
}


int main(){

	Complex c1(10,20);

	Complex c2 = c1;		//Copy constructor: implemented Deep copy otherwise shallow copy

	Complex c3;			// Object creation

	c3 = c2;				// Object Assignment: implemented Deep copy otherwise shallow copy

	return 0;
}

int main1() {

	int a = 10;

//	int b = a++;		//post increment

//	int b = ++a;		// pre increment

	Complex c1(10,20);

	Complex c2 = c1++;	// post increment for Complex object

	c2.display();

	Complex c3 = ++c1;

	c3.display();

	// ostream object & Complex object
	cout << c2;

//	cout.operator<<(c2);

	Complex c4;

	cout << "Enter Complex Number: " <<endl;
	cin >> c4;

	cout << c4 << endl;

	return 0;
}
