//============================================================================
// Name        : 5.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Animal{
protected:
	int legs;
public:

	void eat(){
		cout << "Animal eating.." << endl;
	}

	void makeSound(){
		cout << "Animal Make Sound.." << endl;
	}

	void walk(){
		cout << "Animal Walking.." << endl;
	}
};	// Base Class : Parent Class : Generalization


// Mode of Inheritance-  public : protected : private
class Human : public Animal{
public:
	void think(){
		cout << "Human thinking.." << endl;
	}

	void code(){
		cout << "Human coding.." << endl;
	}

	void showLegs(){
		cout << legs << endl;
	}
};	//Derived Class : Child Class : Specialization


// Types of Inheritance
// Single		: One Base class -> One Derived class
// Multiple		: Multiple Base classes -> One Derived class
// Multilevel	: One Base class -> One Derived class -> Another Derived Class
// Heirarchical	: One Base class -> Multiple Derived classes
// Hybrid		: Combination that cause Diamond shape



// Single Inheritance
class A{
public:
	int x;	//4
};


class B : virtual public A{

};

// Multilevel
class C : public B{

};

// Heirarchical
class D : virtual public A{

};


// Multiple - Hybrid
class E : public B, public D{

};

//	 A
//	/ \
//	B  D
//	\ /
//	 E

// Diamond problem


int main(){

	E e;

	cout << sizeof(e) << endl;
	cout << e.x << endl;		//Diamond Problem

	return 0;
}



int main1() {

	Human h;		// Derived class

	h.eat();		// Base class
	h.think();	// Derived class

	return 0;
}
