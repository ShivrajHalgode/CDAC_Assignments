/*
 * main.cpp
 *
 *  Created on: 04-Mar-2026
 *      Author: Shilbhushan
 */

#include <iostream>

using namespace std;

class Array{
	int* arr;
	int size;

public:

	//default cons
	Array():arr(nullptr), size(0){
	}

	// para cons
	Array(int size) : size(size){
		this->arr = new int[size];

		for(int i=0;i<size;i++)
			arr[i] = 0;
	}

	// Deep Copy cons
	Array(const Array& other){
		this->size = other.size;
		arr = new int[size];

		for(int i=0;i<size;i++)
			this->arr[i] = other.arr[i];
	}

	// Assigment operator overloading	Array a; Array b = a; b = a; b.operator=(a)
	Array& operator=(Array other){
		if(this == &other)		// a = a
			return *this;

		delete[] arr;		// older object ->

		this->size = other.size;
		arr = new int[size];
		for(int i=0;i<size;i++)
			this->arr[i] = other.arr[i];
		return *this;
	}


	int operator[](int index){
		if(index < 0 || index >=size)
			throw out_of_range("Out of Range...");
		return arr[index];	//int value
	}

	~Array(){
		delete[] arr;
	}

};



int main(){

	Array a(2);		// size 2

	int num = a[0];

	Array b = a;		// copy cons		: a.arr -> 1000	b.arr -> 1000

	Array c;

	c = a;			// assignment : : a.arr -> 1000	b.arr -> 1000

	int val = b[1];	// index 2+1 = 3

	cout << val << endl;
	cout << num << endl;

	return 0;
}
