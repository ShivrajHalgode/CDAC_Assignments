#include <iostream>
using namespace std;

//return_type funcName(paramters){
//
//}

extern "C" int add(int num1, int num2){
	return num1 + num2;
}

// function overloading
//int add(int num1, double num2){
//	return num1 + num2;
//}


//int add(int num1, double num2, int num3){
//	return num1 + num2 + num3;
//}

int add(double num1, int num2){
	return num1 + num2;
}



int main() {

	cout << add(10.5,20.5) << endl;

	return 0;
}