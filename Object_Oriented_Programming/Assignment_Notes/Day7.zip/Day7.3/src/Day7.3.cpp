//============================================================================
// Name        : 3.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Complex{
	int real, imag;

public:
	Complex() : real(0), imag(0){

	}

	Complex(int real, int imag) : real(real), imag(imag){

	}

	int getImag() const {
		return imag;
	}

	void setImag(int imag) {
		this->imag = imag;
	}

	int getReal() const {
		return real;
	}

	void setReal(int real) {
		this->real = real;
	}

	void print(){
		cout << real << " + " << imag << "i" << endl;
	}

	//member function *this
//	Complex operator+(Complex& c){
//		return Complex(this->real + c.real, this->imag + c.imag);
//	}

	friend Complex operator+(Complex& first, Complex& second);
	friend Complex operator+(int first, Complex& second);

	bool operator==(Complex& c){
		return (this->real == c.real) && (this->imag == c.imag);
	}

	bool operator<(Complex& c){
		return (this->real < c.real) && (this->imag < c.imag);
	}

	friend bool operator<=(Complex& first, Complex& second);

	auto operator<=>(Complex& c) const = default;
};

Complex operator+(Complex& first, Complex& second){
	return Complex(first.real + second.real, first.imag + second.imag);
}

Complex operator+(int first, Complex& second){
	return Complex(first + second.real, second.imag);
}

// for <= operator non member function
bool operator<=(Complex& first, Complex& second){
	return (first.real < second.real) && (first.imag < second.imag);
}

int main() {

	int a = 10;
	int b = 20;

	int c = a + b;	// local variable: primitive datatypes

	cout << "Sum of Int: " << c << endl;

	Complex c1(10, 20);
	Complex c2(30, 40);


	c1.print();
	c2.print();

	Complex c3;

	c3 = c1 + c2; // Member
	//	 c1.operator +(c2);	//internally your compiler converts it for member function
	// operator(&c1, c2);

	//Non-Member
	// operator+(c1,c2);

	c3.print();

	Complex c4 = 50 + c2;	//Non-Member

	c4.print();

	if(a == b)
		cout << "a is equal to b" << endl;
	else
		cout << "a is not equal to b" << endl;


	if(c1 == c2)
		cout << "Both complex numbers are equal." << endl;
	else
		cout << "Both complex numbers are not equal." << endl;

	if(c1 <= c2)
		cout << "first is less than or equal to second." << endl;
	else
		cout << "first is not less than or equal to second." << endl;

//	< > <= => == != : c++20 <=>

	return 0;
}
