//============================================================================
// Name        : 1.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Student{
	int rollNo;
	float marks;
	static string course;	// static variable declaration
	static int totalStudent;

public:

	Student() : rollNo(0), marks(0){
		totalStudent++;
	}

	Student(int rollNo, float marks) : rollNo(rollNo), marks(marks){
		totalStudent++;
	}

	float getMarks() const {
		return marks;
	}

	void setMarks(float marks) {
		this->marks = marks;
	}

	int getRollNo() const {
		return rollNo;
	}

	void setRollNo(int rollNo) {
		this->rollNo = rollNo;
	}

	//normal member function
	static const string& getCourse() {
		return course;
	}

	void setCourse(const string &course) {
		this->course = course;
	}

	static int getTotalStudent() {
		return totalStudent;
	}

	void setTotalStudent(int totalStudent) {
		this->totalStudent = totalStudent;
	}

	static void getStudentsAndCourse(){
		cout << "Total Student: " << totalStudent << " | Course: " << course << endl;
	}
};

string Student::course = "PGCP-AC";
int Student::totalStudent = 0;

int main() {

	Student s1(121, 48);

	cout << "Total Student : "<< Student::getTotalStudent() << endl; // static

	Student s2(132, 67);

	Student s3;

	cout << "Total Student : "<< Student::getTotalStudent() << endl;
															// s1.getCourse() : not recommended
	cout << s1.getRollNo() << " | " << s1.getMarks() << " | "<< Student::getCourse() << endl;
	cout << s2.getRollNo() << " | " << s2.getMarks() << " | "<< Student::getCourse() << endl;

	Student::getStudentsAndCourse();

	return 0;
}
