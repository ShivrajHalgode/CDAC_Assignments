//============================================================================
// Name        : 2.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

//class Student;	// forward declaration

class Student{
	int rollNo;
	string name;
	float marks;
public:

	Student(): rollNo(0), name(""), marks(0){

	}

	Student(int rollNo, string name, float marks): rollNo(rollNo), name(name), marks(marks){

	}

	friend void displayStudent(Student&);	// friend function
	friend class Faculty;					// friend class
};

class Faculty{
	public:

	void generateResult(Student& s){
		cout << s.rollNo << " | " << s.name << " | " << s.marks << endl;
	}

	void graceMarks(Student& s){
		s.marks + 5.5;
		cout << s.rollNo << " | " << s.name << " | " << s.marks << endl;
	}
};

void displayStudent(Student& s){
	cout << s.rollNo << " | " << s.name << endl;
}


int main(){

	Student s1(121,"shil", 40);


	Faculty f1;

	f1.generateResult(s1);	// faculty -> generating result


	return 0;
}

int main1() {

	Student s1(121, "shil", 45);

//	cout << s1.getRollNo() << " | " << s1.getName() << endl;

	displayStudent(s1);	//call to global function

	return 0;
}
